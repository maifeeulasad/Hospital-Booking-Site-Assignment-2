package com.mua.hbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
