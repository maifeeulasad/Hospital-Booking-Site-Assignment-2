package com.mua.hbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HbsApplication.class, args);
	}

}
